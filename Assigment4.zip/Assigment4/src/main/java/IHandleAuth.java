public interface IHandleAuth {
    public String getLogin();

    public void setLogin(String login);

    public int getCount();

    public void setCount(int count);

    public int getCount2();

    public void setCount2(int count2);

    public int getCount3();

    public void setCount3(int count3);

    public String getPass();

    public void setPass(String pass);
}
